import sys 
from PyQt5.uic import loadUi
from PyQt5.QtWidgets import *
from PyQt5 import QtCore, QtGui, QtWidgets
def search_in_single_column(self, search_term, column_index):
        """Search for the term in a single specified column and update the data grid."""
        self.Data_Grid.setModel(QtGui.QStandardItemModel())  # Clear current grid
        model = QtGui.QStandardItemModel()
        model.setHorizontalHeaderLabels(self.df.columns.tolist())  # Set headers

        matched_rows = set()  # To store unique matching rows

    # Search term in the selected column
        for row_index, row in enumerate(self.df.values.tolist()):
            if search_term.lower() in str(row[column_index]).lower():
                matched_rows.add(row_index)  # Add the matching row index to the set

    # Populate the data grid with the matching rows
        for row_index in matched_rows:
            items = [QtGui.QStandardItem(str(field)) for field in self.df.iloc[row_index]]
            model.appendRow(items)

        self.Data_Grid.setModel(model)

        if model.rowCount() == 0:
            QMessageBox.information(self, 'No Results', 'No data found for the search term.')
def search_in_multiple_columns_and(self, search_term, columns_to_search):
        """Search for the term in multiple columns where all conditions (AND) must be met."""
        self.Data_Grid.setModel(QtGui.QStandardItemModel())  # Clear current grid
        model = QtGui.QStandardItemModel()
        model.setHorizontalHeaderLabels(self.df.columns.tolist())  # Set headers

        matched_rows = set()  # To store unique matching rows
        if len(columns_to_search) < 2:
            QMessageBox.warning(self, 'Selection Error', 'Please select at least two columns for AND search.')
            return
    # Search term in all specified columns (AND logic)
        for row_index, row in enumerate(self.df.values.tolist()):
            if all(search_term.lower() in str(row[col_idx]).lower() for col_idx in columns_to_search):
                matched_rows.add(row_index)

    # Populate the data grid with the matching rows
        for row_index in matched_rows:
            items = [QtGui.QStandardItem(str(field)) for field in self.df.iloc[row_index]]
            model.appendRow(items)

        self.Data_Grid.setModel(model)

        if model.rowCount() == 0:
            QMessageBox.information(self, 'No Results', 'No data found for the search term.')

def search_in_multiple_columns_or(self, search_term, columns_to_search):
        """Search for the term in multiple columns where any condition (OR) can be met."""
        self.Data_Grid.setModel(QtGui.QStandardItemModel())  # Clear current grid
        model = QtGui.QStandardItemModel()
        model.setHorizontalHeaderLabels(self.df.columns.tolist())  # Set headers

        matched_rows = set()  # To store unique matching rows

    # Search term in any of the specified columns (OR logic)
        for row_index, row in enumerate(self.df.values.tolist()):
            if any(search_term.lower() in str(row[col_idx]).lower() for col_idx in columns_to_search):
                matched_rows.add(row_index)

    # Populate the data grid with the matching rows
        for row_index in matched_rows:
            items = [QtGui.QStandardItem(str(field)) for field in self.df.iloc[row_index]]
            model.appendRow(items)

        self.Data_Grid.setModel(model)

        if model.rowCount() == 0:
            QMessageBox.information(self, 'No Results', 'No data found for the search term.')

def search_in_multiple_columns_not(self, search_term, columns_to_search):
        """Search for the term in multiple columns where the term must NOT be in any column."""
        self.Data_Grid.setModel(QtGui.QStandardItemModel())  # Clear current grid
        model = QtGui.QStandardItemModel()
        model.setHorizontalHeaderLabels(self.df.columns.tolist())  # Set headers

        matched_rows = set()  # To store unique matching rows

    # Search term in all specified columns (NOT logic)
        for row_index, row in enumerate(self.df.values.tolist()):
            if all(search_term.lower() not in str(row[col_idx]).lower() for col_idx in columns_to_search):
                matched_rows.add(row_index)

    # Populate the data grid with the matching rows
        for row_index in matched_rows:
            items = [QtGui.QStandardItem(str(field)) for field in self.df.iloc[row_index]]
            model.appendRow(items)

        self.Data_Grid.setModel(model)

        if model.rowCount() == 0:
            QMessageBox.information(self, 'No Results', 'No data found for the search term.')
