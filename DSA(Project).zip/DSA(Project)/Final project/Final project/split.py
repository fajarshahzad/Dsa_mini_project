import pandas as pd

# Define a function to split full name into username and repo name
def split_full_name(full_name):
    # Split the full name at the '/'
    parts = full_name.split('/')
    
    # Ensure there are exactly two parts (organization and repo)
    if len(parts) == 2:
        username = parts[0].lower()  # organization or user name
        repo_name = parts[1].lower()  # repo name
    else:
        username = full_name.lower()  # Default if '/' not found
        repo_name = f"{username}-repo"  # Default repo name if format is unexpected
    
    return username, repo_name

