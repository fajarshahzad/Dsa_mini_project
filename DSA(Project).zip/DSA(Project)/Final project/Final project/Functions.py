from PyQt5 import QtWidgets

def bubble_sort_with_progress(main_window, data):
    
    def convert_value(val):
        # Try to convert to a number, otherwise keep it as is
        try:
            return float(val), 'num'
        except ValueError:
            return str(val), 'str'

    n = len(data)
    indices = list(range(n))

    for i in range(n):
        for j in range(0, n - i - 1):
            # Get both values to compare
            val1, type1 = convert_value(data[j])
            val2, type2 = convert_value(data[j + 1])
            
            # Compare numbers with numbers, and strings with strings
            if type1 == type2:  # Same type, directly compare
                if val1 > val2:
                    data[j], data[j + 1] = data[j + 1], data[j]
                    indices[j], indices[j + 1] = indices[j + 1], indices[j]
            else:  # Different types, compare as strings
                if str(val1) > str(val2):
                    data[j], data[j + 1] = data[j + 1], data[j]
                    indices[j], indices[j + 1] = indices[j + 1], indices[j]

        # Update progress bar: progress depends on outer loop completion
        progress = int((i / n) * 100)
        main_window.progressBar_2.setValue(progress)

        # Allow Qt to update the GUI (progress bar) while sorting
        QtWidgets.QApplication.processEvents()

    return data, indices

def selection_sort_with_progress(main_window, data):
  
    def convert_value(val):
        # Try to convert to a number, otherwise keep it as a string
        try:
            return float(val), 'num'
        except ValueError:
            return str(val), 'str'
    n = len(data)
    indices = list(range(n))
    for i in range(n):
        min_idx = i
        for j in range(i + 1, n):
            # Get converted values for comparison
            val_j, type_j = convert_value(data[j])
            val_min, type_min = convert_value(data[min_idx])
            # Compare values of the same type directly
            if type_j == type_min:
                if val_j < val_min:
                    min_idx = j
            else:
                # If types differ, compare as strings
                if str(val_j) < str(val_min):
                    min_idx = j
        # Swap the elements and their indices
        data[i], data[min_idx] = data[min_idx], data[i]
        indices[i], indices[min_idx] = indices[min_idx], indices[i]
        # Update progress bar
        progress = int((i / n) * 100)
        main_window.progressBar_2.setValue(progress)
        QtWidgets.QApplication.processEvents()
    return data, indices

def insertion_sort_with_progress(main_window, data):
    
    def convert_value(val):
        # Try to convert to a number, otherwise keep it as a string
        try:
            return float(val), 'num'
        except ValueError:
            return str(val), 'str'

    n = len(data)
    indices = list(range(n))

    for i in range(1, n):
        key = data[i]
        key_index = indices[i]
        j = i - 1

        # Get the type and value of the key
        key_val, key_type = convert_value(key)

        while j >= 0:
            # Get the type and value of the current item
            current_val, current_type = convert_value(data[j])

            # Compare values based on their types
            if key_type == current_type:  # Same type, compare directly
                if key_val < current_val:
                    data[j + 1] = data[j]
                    indices[j + 1] = indices[j]
                else:
                    break
            else:  # Different types, compare as strings
                if str(key_val) < str(current_val):
                    data[j + 1] = data[j]
                    indices[j + 1] = indices[j]
                else:
                    break
                
            j -= 1

        # Place the key in its correct position
        data[j + 1] = key
        indices[j + 1] = key_index

        # Update progress bar
        progress = int((i / n) * 100)
        main_window.progressBar_2.setValue(progress)
        QtWidgets.QApplication.processEvents()

    return data, indices   

def quick_sort_with_progress(main_window, arr):
    if len(arr) <= 1:
        return arr, list(range(len(arr)))  # Return array and original indices if length <= 1
# Define a custom comparison function
    def type_order(value):
        if isinstance(value, (int, float)):
            return (0, value)  # Numeric types come first
        elif isinstance(value, str):
            return (1, value)  # Strings come second
        return (2, value)  # Other types can be pushed at the end if necessary
# Track original indices
    indices = list(range(len(arr)))
# Recursive quicksort with index tracking
    def quick_sort_recursive(arr, idx):
        if len(arr) <= 1:
            return arr, idx  # Base case: return array and indices if length <= 1
        pivot = arr[len(arr) // 2]
        left = [arr[i] for i in range(len(arr)) if type_order(arr[i]) < type_order(pivot)]
        left_idx = [idx[i] for i in range(len(arr)) if type_order(arr[i]) < type_order(pivot)]
    
        middle = [arr[i] for i in range(len(arr)) if type_order(arr[i]) == type_order(pivot)]
        middle_idx = [idx[i] for i in range(len(arr)) if type_order(arr[i]) == type_order(pivot)]
    
        right = [arr[i] for i in range(len(arr)) if type_order(arr[i]) > type_order(pivot)]
        right_idx = [idx[i] for i in range(len(arr)) if type_order(arr[i]) > type_order(pivot)]
        sorted_left, sorted_left_idx = quick_sort_recursive(left, left_idx)
        sorted_right, sorted_right_idx = quick_sort_recursive(right, right_idx)
    # Update progress bar
        progress = int((len(sorted_left) + len(middle)) / len(arr) * 100)
        main_window.progressBar_2.setValue(progress)
        QtWidgets.QApplication.processEvents()
        return sorted_left + middle + sorted_right, sorted_left_idx + middle_idx + sorted_right_idx
# Start quicksort
    sorted_arr, sorted_indices = quick_sort_recursive(arr, indices)
# Update progress bar to 100% after sorting is done
    main_window.progressBar_2.setValue(100)
    QtWidgets.QApplication.processEvents()
    return sorted_arr, sorted_indices


def counting_sort_with_progress(main_window, data):
        """Counting sort algorithm with progress bar updates."""
        if not all(isinstance(x, (int, float)) for x in data):
            QtWidgets.QMessageBox.warning(None, "Warning", "Counting sort can only be applied to numeric data.")
        max_val = max(data)
        min_val = min(data)
        range_of_elements = max_val - min_val + 1
        count_arr = [0] * range_of_elements
        output_arr = [0] * len(data)
        indices = list(range(len(data)))
        output_indices = [0] * len(data)

        for i in range(len(data)):
            count_arr[data[i] - min_val] += 1

        for i in range(1, len(count_arr)):
            count_arr[i] += count_arr[i - 1]

        for i in range(len(data) - 1, -1, -1):
            output_arr[count_arr[data[i] - min_val] - 1] = data[i]
            output_indices[count_arr[data[i] - min_val] - 1] = indices[i]
            count_arr[data[i] - min_val] -= 1

            # Update progress bar
            progress = int(((len(data) - i) / len(data)) * 100)
            main_window.progressBar_2.setValue(progress)
            QtWidgets.QApplication.processEvents()

        return output_arr, output_indices

def radix_sort_with_progress(main_window, data):
        """Radix sort algorithm with progress bar updates."""
        # Check if the data contains any non-numeric elements (e.g., strings)
        if not all(isinstance(x, (int, float)) for x in data):
            QtWidgets.QMessageBox.warning(None, "Warning", "Radix sort can only be applied to numeric data.")
            return data, list(range(len(data)))  # Return the original data unchanged
    
    # Convert floats to integers by scaling (since radix sort works with integers)
        scale_factor = 1
        if any(isinstance(x, float) for x in data):
            scale_factor = 10 ** max(len(str(x).split('.')[1]) for x in data if isinstance(x, float))
            data = [int(x * scale_factor) for x in data]
        indices = list(range(len(data)))

        def counting_sort_for_radix(arr, idx, exp):
            n = len(arr)
            output = [0] * n
            output_idx = [0] * n
            count = [0] * 10

            for i in range(n):
                index = arr[i] // exp
                count[index % 10] += 1

            for i in range(1, 10):
                count[i] += count[i - 1]

            for i in range(n - 1, -1, -1):
                index = arr[i] // exp
                output[count[index % 10] - 1] = arr[i]
                output_idx[count[index % 10] - 1] = idx[i]
                count[index % 10] -= 1

            for i in range(n):
                arr[i] = output[i]
                idx[i] = output_idx[i]
        max_val = max(data)
        exp = 1
        total_digits = len(str(max_val))

    # Perform radix sort (using counting sort as a subroutine) for each digit
        while max_val // exp > 0:
            counting_sort_for_radix(data, indices, exp)
            exp *= 10

        # Update the progress bar based on the current digit being processed
            progress = int((exp / (10 ** total_digits)) * 100)
            main_window.progressBar_2.setValue(progress)
            QtWidgets.QApplication.processEvents()

    # If floats were scaled, scale them back to original values
        if scale_factor > 1:
            data = [x / scale_factor for x in data]

    # Update the progress bar to 100%
        main_window.progressBar_2.setValue(100)
        QtWidgets.QApplication.processEvents()

        return data, indices        

def bucket_sort_with_progress(main_window, data):
        """Bucket sort algorithm with progress bar updates, only for integer data."""
        
        # Check if the data contains any non-integer elements
        if not all(isinstance(x, int) for x in data):
            QtWidgets.QMessageBox.warning(None, "Warning", "Bucket sort can only be applied to integer data.")
            return data, list(range(len(data)))  # Return the original data unchanged

        n = len(data)
        if n == 0:
            return [], []  # If the data is empty, return empty results

        # Determine the range for bucket distribution
        max_val = max(data)
        min_val = min(data)

        # Create buckets and bucket_indices for sorting
        bucket_count = n
        buckets = [[] for _ in range(bucket_count)]
        bucket_indices = [[] for _ in range(bucket_count)]
        indices = list(range(n))

        # Assign each item to a bucket
        for i in range(n):
            # Calculate the bucket index based on the normalized range of data
            if max_val == min_val:
                bucket_index = 0  # If all elements are the same, use the first bucket
            else:
                bucket_index = int((data[i] - min_val) / (max_val - min_val) * (bucket_count - 1))

            buckets[bucket_index].append(data[i])
            bucket_indices[bucket_index].append(indices[i])

        # Sort each bucket and update results
        result = []
        result_indices = []
        for i in range(bucket_count):
            # Sort each bucket
            sorted_bucket = sorted(zip(buckets[i], bucket_indices[i]), key=lambda x: x[0])
            result.extend([x[0] for x in sorted_bucket])
            result_indices.extend([x[1] for x in sorted_bucket])

            # Update progress bar
            progress = int((i / bucket_count) * 100)
            main_window.progressBar_2.setValue(progress)
            QtWidgets.QApplication.processEvents()

        return result, result_indices        


def merge_sort_with_progress(main_window, data):
    
    indices = list(range(len(data)))
    def convert_value(val):
        # Try to convert to a number, otherwise keep it as a string
        try:
            return float(val), 'num'
        except ValueError:
            return str(val), 'str'
    def merge_sort_recursive(arr, idx):
        if len(arr) > 1:
            mid = len(arr) // 2
            L = arr[:mid]
            R = arr[mid:]
            L_idx = idx[:mid]
            R_idx = idx[mid:]
            merge_sort_recursive(L, L_idx)
            merge_sort_recursive(R, R_idx)
            i = j = k = 0
            while i < len(L) and j < len(R):
                # Get converted values and types
                L_val, L_type = convert_value(L[i])
                R_val, R_type = convert_value(R[j])
                # Compare values based on type
                if L_type == R_type:  # Same type, compare directly
                    if L_val < R_val:
                        arr[k] = L[i]
                        idx[k] = L_idx[i]
                        i += 1
                    else:
                        arr[k] = R[j]
                        idx[k] = R_idx[j]
                        j += 1
                else:  # Different types, compare as strings
                    if str(L_val) < str(R_val):
                        arr[k] = L[i]
                        idx[k] = L_idx[i]
                        i += 1
                    else:
                        arr[k] = R[j]
                        idx[k] = R_idx[j]
                        j += 1
                k += 1
            while i < len(L):
                arr[k] = L[i]
                idx[k] = L_idx[i]
                i += 1
                k += 1
            while j < len(R):
                arr[k] = R[j]
                idx[k] = R_idx[j]
                j += 1
                k += 1
    # Call the recursive merge sort function
    merge_sort_recursive(data, indices)
    # Update progress bar to 100% after sorting is complete
    main_window.progressBar_2.setValue(100)
    QtWidgets.QApplication.processEvents()
    return data, indices


def comb_sort_mixed_large(main_window, data):
    def convert_value(val):
        """
        Convert to float if possible, otherwise return as string for uniform comparison.
        """
        try:
            return float(val), 'num'
        except ValueError:
            return str(val), 'str'
    n = len(data)
    gap = n
    shrink_factor = 1.3
    swapped = True
    indices = list(range(n))
    while gap > 1 or swapped:
        # Reduce the gap value
        gap = int(gap / shrink_factor)
        if gap < 1:
            gap = 1
        swapped = False
        # Compare elements with the current gap
        for i in range(n - gap):
            j = i + gap
            val_i, type_i = convert_value(data[i])
            val_j, type_j = convert_value(data[j])
            # Compare values based on their types
            if type_i == type_j:  # Same type, compare directly
                if val_i > val_j:
                    data[i], data[j] = data[j], data[i]
                    indices[i], indices[j] = indices[j], indices[i]
                    swapped = True
            else:  # Different types, compare as strings
                if str(val_i) > str(val_j):
                    data[i], data[j] = data[j], data[i]
                    indices[i], indices[j] = indices[j], indices[i]
                    swapped = True
        # Update progress bar
        progress = int(((n - gap) / n) * 100)
        main_window.progressBar_2.setValue(progress)
        QtWidgets.QApplication.processEvents()
    return data, indices

def shell_sort_with_progress(main_window, data):
        """Shell sort algorithm with progress bar updates."""
        n = len(data)
        indices = list(range(n))
        gap = n // 2

        def type_order(value):
            """Custom ordering function to handle both numbers and strings."""
            if isinstance(value, (int, float)):
                return (0, value)  # Numeric types come first
            elif isinstance(value, str):
                return (1, value)  # Strings come second
            return (2, value)  # Other types (if any) can be pushed to the end

        while gap > 0:
            for i in range(gap, n):
                temp = data[i]
                temp_idx = indices[i]
                j = i
            # Corrected comparison: using custom type_order function
                while j >= gap and type_order(data[j - gap]) > type_order(temp):
                    data[j] = data[j - gap]
                    indices[j] = indices[j - gap]
                    j -= gap
                data[j] = temp
                indices[j] = temp_idx

        # Update progress bar based on gap reduction
            progress = int(((n // gap) / n) * 100)
            main_window.progressBar_2.setValue(progress)

        # Allow Qt to update the GUI (progress bar) while sorting
            QtWidgets.QApplication.processEvents()

            gap //= 2  # Reduce the gap size

    # Final update to 100% progress
        main_window.progressBar_2.setValue(100)
        QtWidgets.QApplication.processEvents()

        return data, indices
