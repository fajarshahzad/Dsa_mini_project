import sys
import time
from PyQt5.uic import loadUi
from PyQt5.QtWidgets import *
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QMainWindow, QApplication, QMessageBox, QTableView,QTextEdit,QPushButton
import pandas as pd
from PyQt5.QtCore import QThread, pyqtSignal
from selenium import webdriver
from bs4 import BeautifulSoup
from selenium.webdriver.chrome.service import Service
from selenium.common.exceptions import TimeoutException
import split
import convert
from PyQt5.QtCore import QThread, pyqtSignal
from selenium.common.exceptions import TimeoutException


class InnerScrapThread(QThread):
    dataScraped = pyqtSignal(pd.DataFrame)
    updateProgress = pyqtSignal(int)

    def __init__(self,Mainwindow):
        super(InnerScrapThread, self).__init__()
        self.isPaused = Mainwindow.isPaused
        self.isEnded = Mainwindow.isEnded
        self.Window = Mainwindow
        self.service = Service(executable_path="F:\\3rd Sem\\DSA Lab\\Week 3\\chromedriver-win64\\chromedriver.exe")
        self.options = webdriver.ChromeOptions()
        self.options.add_argument('--blink-settings=imagesEnabled=false')
        self.options.add_experimental_option("prefs", {"profile.managed_default_content_settings.images": 2})

    def run(self):
        driver = webdriver.Chrome(service=self.service, options=self.options)
        Issues = []
        Forks = []
        Data = pd.read_csv('Github2.csv')
        Names = Data["Name"].values.tolist()
        for i in Names:
            if self.isEnded == False:
                while self.isPaused:  # If paused, check until resumed
                        time.sleep(1)    
                try:
                    driver.get(f'https://github.com/{i}')
                    time.sleep(0.5) 
                    content = driver.page_source
                    soup2 = BeautifulSoup(content, features="html.parser") 
                    for a in soup2.findAll("ul", attrs={"class":"UnderlineNav-body"}):
                        start_time = time.time()
                        issuesCount = a.find("span",attrs = {"id":"issues-repo-tab-count"}) 
                        Issues.append(issuesCount.text.strip() if issuesCount else 0)
                    ForksCount = soup2.find("span",attrs={"id":"repo-network-counter"})
                    Forks.append(ForksCount.text.strip() if ForksCount else 0)
                    Data.loc[Data["Name"] == i, "Forks"] = Forks[-1]  # Update the last appended value
                    Data.loc[Data["Name"] == i, "Issues"] = Issues[-1]  # Update the last appended value
                    # Save to CSV
                    Data.to_csv('Github2.csv', index=False)
                except TimeoutException:
                    print(f"Timeout while accessing {i}, skipping...")
                except Exception as e:
                    print(f'error scrapping {i}: {e}')       
                finally:
                    endTime = time.time()
                    totalTime = endTime-start_time
                    print(f'{i} has taken {totalTime} ms to get data')
                    time.sleep(0.5)
            else:
                 break        
        convert.Main('Github2.csv')                 
        driver.quit()               
   
    
class ScraperThread(QThread):
    dataScraped = pyqtSignal(pd.DataFrame)
    updateProgress = pyqtSignal(int)
    def __init__(self, minPage, maxPage, Window):
        super(ScraperThread, self).__init__()
        self.minPage = minPage
        self.maxPage = maxPage
        self.isPaused = False
        self.scrapper_thread = None
        self.mainWindow = Window
        self.inner_scrap_thread = None
    def run(self):
        Name = []
        Description = []
        Language = []
        Stars = []
        UserName = []
        RepoName = []
        service = Service(executable_path="F:\\3rd Sem\\DSA Lab\\Week 3\\chromedriver-win64\\chromedriver.exe")
        options = webdriver.ChromeOptions()
        driver = webdriver.Chrome(service=service, options=options)
        options.add_argument('--blink-settings=imagesEnabled=false')
        options.add_argument('--headless')
        options.add_experimental_option("prefs", {"profile.managed_default_content_settings.images": 2})

        try:
            for i in range(self.minPage, self.maxPage):
                    if window.isEnded == False:
                        while self.isPaused:  # If paused, check until resumed
                            time.sleep(1) 
                        driver.get(f'https://github.com/search?q=x&type=repositories&p={i}')
                        content = driver.page_source
                        soup = BeautifulSoup(content, features="html.parser")
                        for a in soup.findAll("div", attrs={"class": "flszRz"}):
                            name = a.find("a", attrs={"class": "dIlPa"})
                            RepoDescription = a.find("span", attrs={"class": "cWNlgR"})
                            language = a.find("li", attrs={"class": "iyzdzM"})
                            StarsGained = a.find("span", attrs={"class": "hWqAbU"})

                            if language and StarsGained and language.text == StarsGained.text:
                                language.string = 'no language'

                            if name and RepoDescription and language and StarsGained:
                                Name.append(name.text)
                                username,reponame = split.split_full_name(name.text)
                                UserName.append(username)
                                RepoName.append(reponame)
                                Description.append(RepoDescription.text)
                                Language.append(language.text)
                                Stars.append(StarsGained.text)
                            progressPercentage = int(((i-self.minPage+1) / (self.maxPage-self.minPage)) * 100)
                            self.updateProgress.emit(progressPercentage)
                            df = pd.DataFrame({"RepoName": RepoName, "Name":Name, "Description": Description, "Language": Language,"UserName":UserName, "Stars Gained": Stars})
                            self.dataScraped.emit(df)
                        time.sleep(0.3)
                    else:
                         driver.quit()
                         break
                         
            driver.quit()
        except Exception as ex:
            QMessageBox.warning(self,'Error',f"Could not scrap data due to {ex}")
        finally:
            driver.quit()
        try:    
            inner_scrap_thread = InnerScrapThread(self.mainWindow)
            inner_scrap_thread.dataScraped.connect(self.mainWindow.saveData)
            inner_scrap_thread.updateProgress.connect(self.mainWindow.updateProgress)
            inner_scrap_thread.start()
            print("inner scrap thread initialized")
        except Exception as ex:
            print({str(ex)})    
            
        
class Mainwindow(QMainWindow):
    isPaused = False
    isEnded = False
    def __init__(self) -> None:
          super(Mainwindow,self).__init__()
          try:
               loadUi('scrappinUI.ui',self)
               self.setWindowFlag(QtCore.Qt.FramelessWindowHint)
               self.startButton.clicked.connect(self.StartScrapping)
               self.stopButton.clicked.connect(self.setPause)
               self.resumeButton.clicked.connect(self.setResume)
               self.minimizeButton.clicked.connect(lambda: self.showMinimized())
               self.CrossButton.clicked.connect(lambda: self.close())
               self.dataTable = QTableView(self)
               self.scraper_thread = None
               self.innerScrapThread = None
               self.EndButton.clicked.connect(self.setEnd)   
               print(f'UI loaded successfully')
          except Exception as ex:
                print(f'Error loading UI due to {str(ex)}')    
    def StartScrapping(self):
        try:
            minPage = int(self.minPageInput.text())
            maxPage = int(self.maxPageInput.text()) 
            if maxPage - minPage <= 30:
                self.scraper_thread = ScraperThread(minPage, maxPage,self)
                self.scraper_thread.dataScraped.connect(self.saveData)
                self.scraper_thread.updateProgress.connect(self.updateProgress)
                self.scraper_thread.start()
            else:
                QMessageBox.warning(self,'error',"Too Many Pages cannot retrieve so much data")
        except Exception as ex:
             QMessageBox.warning(self,'error',f'error starting due to {str(ex)}')
    def updateProgress(self, value):
        try:
            self.progressBar.setValue(value)  
        except Exception as ex:
             QMessageBox.warning(self,'error',f'{str(e)}')
    def setEnd(self):
         self.isEnded = True
         if self.scraper_thread:
            self.scraper_thread.quit()  # Safely terminate scraper thread
         if self.scraper_thread.inner_scrap_thread:
            self.inner_scrap_thread.quit() 
                                         
    def setPause(self):
        # Check if scraper_thread is initialized before setting pause
        if self.scraper_thread:
            self.scraper_thread.isPaused = True  # Pause the thread
        if self.scraper_thread.inner_scrap_thread:  # Check if initialized
            self.isPaused = True
    def setResume(self):
        # Check if scraper_thread is initialized before setting resume
        if self.scraper_thread:
            self.scraper_thread.isPaused = False  # Resume the thread
        if self.scraper_thread.inner_scrap_thread:  # Check if initialized
            self.isPaused = False
    def saveData(self, df):
        try:
            df.to_csv("Github2.csv", encoding="utf-8", index=False, mode="w")
            print("Data stored in Github2")
        except Exception as ex:
             QMessageBox.warning(self,'Error',f'{str(ex)}')    
    def loadData(self):
        try:
                self.df = pd.read_csv('Github2.csv') 
                if not self.df.empty:
                    model = QtGui.QStandardItemModel()
                    model.setHorizontalHeaderLabels(self.df.columns.tolist())
                    for row in self.df.values.tolist():
                        items = [QtGui.QStandardItem(str(field)) for field in row]
                        model.appendRow(items)
                    self.dataTable.setModel(model)
                else:
                    QMessageBox.warning(self,'warning','CSV File is empty')
        except Exception as ex:
                    QMessageBox.warning(self,'error',f'{str(ex)}') 
                                
try:
        app = QApplication(sys.argv)
        window = Mainwindow()
        window.show()
        sys.exit(app.exec_())
except Exception as e:
        QMessageBox.critical(None, "Error", f"An error occurred: {str(e)}")