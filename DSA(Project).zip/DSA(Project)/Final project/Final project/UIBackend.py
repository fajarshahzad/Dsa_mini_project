import sys
import time
from PyQt5.uic import loadUi
from PyQt5.QtWidgets import *
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QMainWindow, QApplication, QMessageBox, QTableView,QTextEdit,QPushButton
import pandas as pd
from PyQt5.QtCore import QThread, pyqtSignal
from selenium import webdriver
from bs4 import BeautifulSoup
from selenium.webdriver.chrome.service import Service
from selenium.common.exceptions import TimeoutException
import split
import convert
from PyQt5.QtCore import QThread, pyqtSignal
from selenium.common.exceptions import TimeoutException
import search as s
from  Functions import bubble_sort_with_progress, selection_sort_with_progress, insertion_sort_with_progress, quick_sort_with_progress, counting_sort_with_progress, radix_sort_with_progress, bucket_sort_with_progress, merge_sort_with_progress, comb_sort_mixed_large, shell_sort_with_progress
class InnerScrapThread(QThread):
    dataScraped = pyqtSignal(pd.DataFrame)
    updateProgress = pyqtSignal(int)

    def __init__(self,Mainwindow):
        super(InnerScrapThread, self).__init__()
        self.isPaused = Mainwindow.isPaused
        self.isEnded = Mainwindow.isEnded
        self.Window = Mainwindow
        self.service = Service(executable_path="C:\\Users\\dell\\Desktop\\Semester3\\DSA(L)\\chromedriver-win64\\chromedriver-win64.exe")
        self.options = webdriver.ChromeOptions()
        self.options.add_argument('--blink-settings=imagesEnabled=false')
        self.options.add_experimental_option("prefs", {"profile.managed_default_content_settings.images": 2})

    def run(self):
        driver = webdriver.Chrome(service=self.service, options=self.options)
        Issues = []
        Forks = []
        Data = pd.read_csv('Github2.csv')
        Names = Data["Name"].values.tolist()
        for i in Names:
            if self.isEnded == False:
                while self.isPaused:  # If paused, check until resumed
                        time.sleep(1)    
                try:
                    driver.get(f'https://github.com/{i}')
                    time.sleep(0.5) 
                    content = driver.page_source
                    soup2 = BeautifulSoup(content, features="html.parser") 
                    for a in soup2.findAll("ul", attrs={"class":"UnderlineNav-body"}):
                        start_time = time.time()
                        issuesCount = a.find("span",attrs = {"id":"issues-repo-tab-count"}) 
                        Issues.append(issuesCount.text.strip() if issuesCount else 0)
                    ForksCount = soup2.find("span",attrs={"id":"repo-network-counter"})
                    Forks.append(ForksCount.text.strip() if ForksCount else 0)
                    Data.loc[Data["Name"] == i, "Forks"] = Forks[-1]  # Update the last appended value
                    Data.loc[Data["Name"] == i, "Issues"] = Issues[-1]  # Update the last appended value
                    # Save to CSV
                    Data.to_csv('Github2.csv', index=False)
                except TimeoutException:
                    print(f"Timeout while accessing {i}, skipping...")
                except Exception as e:
                    print(f'error scrapping {i}: {e}')       
                finally:
                    endTime = time.time()
                    totalTime = endTime-start_time
                    print(f'{i} has taken {totalTime} ms to get data')
                    time.sleep(0.5)
            else:
                 break        
        convert.Main('Github2.csv')                 
        driver.quit()               
class ScraperThread(QThread):
    dataScraped = pyqtSignal(pd.DataFrame)
    updateProgress = pyqtSignal(int)
    def __init__(self, minPage, maxPage, Window):
        super(ScraperThread, self).__init__()
        self.minPage = minPage
        self.maxPage = maxPage
        self.isPaused = False
        self.scrapper_thread = None
        self.mainWindow = Window
        self.inner_scrap_thread = None
    def run(self):
        Name = []
        Description = []
        Language = []
        Stars = []
        UserName = []
        RepoName = []
        service = Service(executable_path="F:\\3rd Sem\\DSA Lab\\Week 3\\chromedriver-win64\\chromedriver.exe")
        options = webdriver.ChromeOptions()
        driver = webdriver.Chrome(service=service, options=options)
        options.add_argument('--blink-settings=imagesEnabled=false')
        options.add_argument('--headless')
        options.add_experimental_option("prefs", {"profile.managed_default_content_settings.images": 2})

        try:
            for i in range(self.minPage, self.maxPage):
                    if window.isEnded == False:
                        while self.isPaused:  # If paused, check until resumed
                            time.sleep(1) 
                        driver.get(f'https://github.com/search?q=x&type=repositories&p={i}')
                        content = driver.page_source
                        soup = BeautifulSoup(content, features="html.parser")
                        for a in soup.findAll("div", attrs={"class": "flszRz"}):
                            name = a.find("a", attrs={"class": "dIlPa"})
                            RepoDescription = a.find("span", attrs={"class": "cWNlgR"})
                            language = a.find("li", attrs={"class": "iyzdzM"})
                            StarsGained = a.find("span", attrs={"class": "hWqAbU"})

                            if language and StarsGained and language.text == StarsGained.text:
                                language.string = 'no language'

                            if name and RepoDescription and language and StarsGained:
                                Name.append(name.text)
                                username,reponame = split.split_full_name(name.text)
                                UserName.append(username)
                                RepoName.append(reponame)
                                Description.append(RepoDescription.text)
                                Language.append(language.text)
                                Stars.append(StarsGained.text)
                            progressPercentage = int(((i-self.minPage+1) / (self.maxPage-self.minPage)) * 100)
                            self.updateProgress.emit(progressPercentage)
                            df = pd.DataFrame({"RepoName": RepoName, "Name":Name, "Description": Description, "Language": Language,"UserName":UserName, "Stars Gained": Stars})
                            self.dataScraped.emit(df)
                        time.sleep(0.3)
                    else:
                         driver.quit()
                         break
                         
            driver.quit()
        except Exception as ex:
            QMessageBox.warning(self,'Error',f"Could not scrap data due to {ex}")
        finally:
            driver.quit()
        try:    
            inner_scrap_thread = InnerScrapThread(self.mainWindow)
            inner_scrap_thread.dataScraped.connect(self.mainWindow.saveData)
            inner_scrap_thread.updateProgress.connect(self.mainWindow.updateProgress)
            inner_scrap_thread.start()
            print("inner scrap thread initialized")
        except Exception as ex:
            print({str(ex)})    
class Mainwindow(QMainWindow):
    isPaused = False
    isEnded = False
    def __init__(self):
        super(Mainwindow, self).__init__()
        try:
            loadUi('UIPro.ui', self)  # Load the UI file
            print("UI loaded successfully")

            # Check if minimizeButton exists in the UI and connect it to minimize the window
            if hasattr(self, 'minimizeButton'):
                self.minimizeButton.clicked.connect(self.showMinimized)
            
            # Check if CrossButton exists in the UI and connect it to close the window
            if hasattr(self, 'CrossButton'):
                self.CrossButton.clicked.connect(self.close)

            # Set the window background attribute
            self.setAttribute(QtCore.Qt.WA_TranslucentBackground)

            # Load the table data
            self.load_table()

            # Connect sorting button (Assumed to exist in your UI)
            if hasattr(self, 'sortButton'):
                self.sortButton.clicked.connect(self.sort_data)
            if hasattr(self,'loader'):
                self.loader.clicked.connect(self.load_table)
            if hasattr(self,'SearchButton'):
                self.SearchButton.clicked.connect(self.perform_search)
            self.startButton.clicked.connect(self.StartScrapping)
            self.stopButton.clicked.connect(self.setPause)
            self.resumeButton.clicked.connect(self.setResume)
            self.scraper_thread = None
            self.innerScrapThread = None
            self.EndButton.clicked.connect(self.setEnd)
            #if hasattr(self,'CSVLoader')
                
        except Exception as ex:
            print(f'Error loading UI: {str(ex)}')

    def reload_data(self):
        """Reload the original data in the data grid."""
        self.load_table()  # Assuming `load_table()` reloads the full data
    def perform_search(self):
        """Perform search when the search button is clicked."""
        try:
            search_term = self.search.text()  # Get the search term from a QLineEdit widget
            selected_column = self.get_selected_column_index()  # Assuming a combo box to select a single column
            multiple_column = [self.get_selected_column_index(), self.get_selected_column_index()]
            columns_to_search = [0, 1, 2, 3, 4, 5, 6]  # Assume 7 columns (index starts from 0)

        # Determine which search type to use based on user input (radio buttons or dropdown)
            search_type = self.searchcombo.currentText()  # Dropdown for search type (Single, AND, OR, NOT)

            if not search_term:  # If the search term is empty, raise a custom error
                raise ValueError("Search term cannot be empty.")

            if search_type == "Search column wise":
                if selected_column is None:
                    raise ValueError("No column selected for search.")
                s.search_in_single_column(self,search_term, selected_column)

            elif search_type == "Search Whole":
                self.perform_search_whole()

            elif search_type == "Search multicolumn using And":
                if None in multiple_column:
                    raise ValueError("Both columns must be selected for AND search.")
                s.search_in_multiple_columns_and(self,search_term, multiple_column)

            elif search_type == "Search multicolumn using OR":
                if None in multiple_column:
                    raise ValueError("Both columns must be selected for OR search.")
                s.search_in_multiple_columns_or(self,search_term, multiple_column)

            elif search_type == "Search using NOT":
                s.search_in_multiple_columns_not(self,search_term, columns_to_search)

            else:
                raise ValueError("Invalid search type selected.")

        except ValueError as ve:
        # Handle specific errors such as empty search term or invalid selection
            QMessageBox.warning(self, 'Input Error', str(ve))

        except IndexError as ie:
        # Handle errors like index out of range for column selection
            QMessageBox.warning(self, 'Index Error', 'Invalid column index selected.')

        except Exception as e:
        # Catch any other unexpected exceptions and log them
            QMessageBox.critical(self, 'Error', f"An unexpected error occurred: {str(e)}")
            print(f"Error: {e}")  # Optionally log the error to the console for debugging
    
    def search_data(self, search_term, columns_to_search):
        #Search for the data in the specified columns and update the data grid with the results.
        self.Data_Grid.setModel(QtGui.QStandardItemModel())  # Clear current grid

        model = QtGui.QStandardItemModel()
        model.setHorizontalHeaderLabels(self.df.columns.tolist())  # Set headers

    # Search for the term in the selected columns
        for row in self.df.values.tolist():
            for col_idx in columns_to_search:
                if search_term.lower() in str(row[col_idx]).lower():
                    items = [QtGui.QStandardItem(str(field)) for field in row]
                    model.appendRow(items)
                    break

    # Update grid with search results
        self.Data_Grid.setModel(model)

        if model.rowCount() == 0:
            QMessageBox.information(self, 'No Results', 'No data found for the search term.')

    def perform_search_whole(self):
        #Perform search when the search button is clicked.
        search_term = self.search.text()  # Get search term
        columns_to_search = [0,1, 2,3,4,5,6]
        self.search_data(search_term,columns_to_search)

    def load_table(self):
        """Load data from CSV into the table view."""
        try:
            # Load the CSV file
            self.df = pd.read_csv('Github.csv')
            print(f"CSV data loaded successfully: {self.df.shape}")

            if not self.df.empty:
                # Create a model for the table
                model = QtGui.QStandardItemModel()
                model.setHorizontalHeaderLabels(self.df.columns.tolist())  # Set header labels

                # Add rows to the model
                for row in self.df.values.tolist():
                    items = [QtGui.QStandardItem(str(field)) for field in row]
                    model.appendRow(items)

                # Assign the model to the QTableView (Data_Grid)
                self.Data_Grid.setModel(model)
                   # Stretch the columns to fit the data
                for i in range(len(self.df.columns)):
                    
                    self.Data_Grid.resizeColumnToContents(i)
                print("Data successfully loaded into table.")
            else:
                QMessageBox.warning(self, 'Warning', 'CSV File is empty')
                print("CSV file is empty")

        except FileNotFoundError:
            QMessageBox.warning(self, 'Error', 'CSV File not found')
            print("CSV file not found")
        except pd.errors.EmptyDataError:
            QMessageBox.warning(self, 'Error', 'CSV file is empty')
            print("CSV file is empty")
        except Exception as ex:
            QMessageBox.warning(self, 'Error', f'Error loading table: {str(ex)}')
            print(f"Error loading table: {str(ex)}")

    def get_selected_column_index(self):
        """Get the selected column index from the table view."""
        selected_indexes = self.Data_Grid.selectionModel().selectedColumns()
        if selected_indexes:
            return selected_indexes[0].column()
        else:
            return None

    def sort_data(self):
        """Sort data using the selected algorithm and update the table with progress."""
        try:
            selected_column_index = self.get_selected_column_index()
            if selected_column_index is None:
                QMessageBox.warning(self, 'Error', 'No column selected for sorting')
                return

            column_data = self.df.iloc[:, selected_column_index].tolist()  # Sorting the selected column
            selected_algorithm = self.txt_algorithm.currentText()

            # Apply the sorting algorithm
            start_time = time.time()

            # Initialize progress bar to 0
            self.progressBar_2.setValue(0)

            if selected_algorithm   == 'Bubble Sort':
                sorted_data, sorted_indices = bubble_sort_with_progress(self,column_data)
            elif selected_algorithm == 'Selection Sort':
                sorted_data, sorted_indices = selection_sort_with_progress(self,column_data)
            elif selected_algorithm == 'Insertion Sort':
                sorted_data, sorted_indices = insertion_sort_with_progress(self,column_data)
            elif selected_algorithm == 'Quick Sort':
                sorted_data, sorted_indices = quick_sort_with_progress(self,column_data)
            elif selected_algorithm == 'Count Sort':
                sorted_data, sorted_indices = counting_sort_with_progress(self,column_data)
            elif selected_algorithm == 'Radix Sort':
                sorted_data, sorted_indices = radix_sort_with_progress(self,column_data)
            elif selected_algorithm == 'Bucket Sort':
                sorted_data, sorted_indices = bucket_sort_with_progress(self,column_data)
            elif selected_algorithm == 'Merge Sort':
                sorted_data, sorted_indices = merge_sort_with_progress(self,column_data)
            elif selected_algorithm == 'Comb Sort':
                sorted_data,sorted_indices = comb_sort_mixed_large(self,column_data)
            elif selected_algorithm == 'Shell Sort':
                sorted_data, sorted_indices = shell_sort_with_progress(self,column_data)    
            else:
                QMessageBox.warning(self, 'Error', 'Unknown sorting algorithm selected')
                return

            end_time = time.time()
            run_time = end_time - start_time

            # Update the DataFrame with sorted data
            self.df = self.df.iloc[sorted_indices].reset_index(drop=True)
            self.reload_sorted_table()

            # Display the sorting runtime
            self.runtime.setText(f'The sorting took {run_time:.5f} seconds')

            # Set progress bar to 100% after completion
            self.progressBar_2.setValue(100)

        except Exception as ex:
            QMessageBox.warning(self, 'Error', f'Error sorting data: {str(ex)}')


    def reload_sorted_table(self):
        """Reload the sorted data into the table."""
        try:
            # Clear the previous data
            model = self.Data_Grid.model()
            model.clear()

            # Reload the sorted data into the table
            model.setHorizontalHeaderLabels(self.df.columns.tolist())

            for row in self.df.values.tolist():
                items = [QtGui.QStandardItem(str(field)) for field in row]
                model.appendRow(items)

            self.Data_Grid.setModel(model)

        except Exception as ex:
            QMessageBox.warning(self, 'Error', f'Error reloading sorted table: {str(ex)}')
    def StartScrapping(self):
        try:
            minPage = int(self.minPageInput.text())
            maxPage = int(self.maxPageInput.text()) 
            if maxPage - minPage <= 60:
                self.scraper_thread = ScraperThread(minPage, maxPage,self)
                self.scraper_thread.dataScraped.connect(self.saveData)
                self.scraper_thread.updateProgress.connect(self.updateProgress)
                self.scraper_thread.start()
            else:
                QMessageBox.warning(self,'error',"Too Many Pages cannot retrieve so much data")
        except Exception as ex:
             QMessageBox.warning(self,'error',f'error starting due to {str(ex)}')
    def updateProgress(self, value):
        try:
            self.progressBar.setValue(value)  
        except Exception as ex:
             QMessageBox.warning(self,'error',f'{str(ex)}')
    def setEnd(self):
         self.isEnded = True
         if self.scraper_thread:
            self.scraper_thread.quit()  # Safely terminate scraper thread
         if self.scraper_thread.inner_scrap_thread:
            self.inner_scrap_thread.quit() 
                                         
    def setPause(self):
        # Check if scraper_thread is initialized before setting pause
        if self.scraper_thread:
            self.scraper_thread.isPaused = True  # Pause the thread
        if self.scraper_thread.inner_scrap_thread:  # Check if initialized
            self.isPaused = True
    def setResume(self):
        # Check if scraper_thread is initialized before setting resume
        if self.scraper_thread:
            self.scraper_thread.isPaused = False  # Resume the thread
        if self.scraper_thread.inner_scrap_thread:  # Check if initialized
            self.isPaused = False
    def saveData(self, df):
        try:
            df.to_csv("Github2.csv", encoding="utf-8", index=False, mode="w")
            print("Data stored in Github2")
        except Exception as ex:
             QMessageBox.warning(self,'Error',f'{str(ex)}')    
        
if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = Mainwindow()
    window.show()
    sys.exit(app.exec())
