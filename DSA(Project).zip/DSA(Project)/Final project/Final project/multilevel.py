import csv
import convert
# Function to perform bubble sort on a list of dictionaries based on multiple keys
def bubble_sort_multilevel(data, sort_columns, ascending_order):
    n = len(data)
    # Bubble sort algorithm
    for i in range(n):
        for j in range(0, n - i - 1):
            # Compare based on multiple columns
            for k in range(len(sort_columns)):
                col = sort_columns[k]
                asc = ascending_order[k]

                # Convert values to numbers if possible
                val1 = (data[j][col])
                val2 = (data[j + 1][col])

                if (asc and val1 > val2) or (not asc and val1 < val2):
                    # Swap if the current row is greater or lesser based on sort order
                    data[j], data[j + 1] = data[j + 1], data[j]
                    break  # Move to next pair of rows after first level sorting
                elif val1 == val2:
                    # If values are equal, continue to the next column
                    continue
                else:
                    break
def insertion_sort_multilevel(data, sort_columns, ascending_order):
    n = len(data)

    # Insertion sort algorithm
    for i in range(1, n):
        key = data[i]
        j = i - 1

        # Compare based on multiple columns
        while j >= 0:
            swap = False
            for k in range(len(sort_columns)):
                col = sort_columns[k]
                asc = ascending_order[k]

                # Convert values to numbers if possible
                val1 = (data[j][col])
                val2 = (key[col])

                if (asc and val1 > val2) or (not asc and val1 < val2):
                    # Shift element if it's out of order
                    data[j + 1] = data[j]
                    swap = True
                    break  # Move to next comparison after first level sorting
                elif val1 == val2:
                    # If values are equal, continue to the next column
                    continue
                else:
                    break

            if not swap:
                break  # Exit the loop if no shifting is needed

            j -= 1

        # Place key in the correct position
        data[j + 1] = key

# Function to read CSV, perform multilevel sorting, and save sorted data
def multilevel_sort_csv_bubble(input_file, output_file, sort_columns, ascending_order):
    try:
        convert.Main('test.csv')
        # Read the CSV file into a list of dictionaries
        with open(input_file, mode='r') as file:
            reader = csv.DictReader(file)
            data = list(reader)

        # Perform Bubble Sort on the data
        # bubble_sort_multilevel(data, sort_columns, ascending_order)
        insertion_sort_multilevel(data,sort_columns,ascending_order)
        # Get the field names from the input file
        fieldnames = data[0].keys()

        # Write the sorted data to a new CSV file
        with open(output_file, mode='w', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(data)

        print(f"Data sorted by {sort_columns} and saved to {output_file}")

    except Exception as e:
        print(f"Error occurred: {e}")

# Example usage
input_file = 'test.csv'  # Path to the input CSV file
output_file = 'test1.csv'  # Path to save the sorted CSV file

# Columns to sort by (multilevel sorting)
sort_columns = ['Forks', 'Issues']  # Replace with your actual column names

# Corresponding ascending/descending order for each column (True for ascending, False for descending)
ascending_order = [True, False]  # Sort 'column1' in ascending order and 'column2' in descending order

# Perform the sorting and save the output
multilevel_sort_csv_bubble(input_file, output_file, sort_columns, ascending_order)
