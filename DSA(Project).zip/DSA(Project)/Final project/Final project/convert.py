import pandas as pd
import numpy as np
def convert_to_numeric(value):
    try:
        # Check if the value is a string before processing
        if isinstance(value, str):
            value = value.lower()  # Convert to lowercase for consistency
            if 'k' in value:
                return float(value.replace('k', '')) * 1000
            elif 'm' in value:
                return float(value.replace('m', '')) * 1000000
            elif '+' in value:
                return float(value.replace('+',''))*1
            else:
                return int(0)    
        # If value is already numeric (float or int), return it as is
        return value
    except Exception as ex:
        print({str(ex)})
def convert_values(value):
    if isinstance(value, int):  # Check if the value is an integer
        return np.nan  # Convert to NaN
    return str(value)  # Convert to string for all other types
def convert_to_int(column_name,Data):
    Data[column_name] = pd.to_numeric(Data[column_name], errors='coerce')

# Fill NaN values with 0 (or any value you choose)
    Data[column_name].fillna(0, inplace=True)

    # Convert the column to integer type
    Data[column_name] = Data[column_name].astype(int)

    # Check the result
    print(Data[column_name])
    print(f"Data type of the column: {Data[column_name].dtype}")

    # Verify if all values are integers
    if pd.api.types.is_integer_dtype(Data[column_name]):
        print("All data in the column is now of type integer.")
    else:
        print("There are still non-integer values in the column.")

def Main(FileName):
    try:
        df = pd.read_csv(FileName)
        # Specify the column where the 'k' values are present (example: 'Count')
        # Apply the conversion function to the entire column
        df['Forks'] = df['Forks'].apply(convert_to_numeric)
        df['Issues'] = df['Issues'].apply(convert_to_numeric)
        df['Stars Gained'] = df['Stars Gained'].apply(convert_to_numeric)
        df['Language'] = df['Language'].apply(convert_values)
        convert_to_int('Forks',df)
        convert_to_int('Issues',df)
        convert_to_int('Stars Gained',df)
        # Save the updated DataFrame back to a CSV file
        df.to_csv(FileName, index=False)
    except Exception as ex:
        print({str(ex)})    
    print("Conversion complete and saved to 'Github.csv'")
# Main()    
