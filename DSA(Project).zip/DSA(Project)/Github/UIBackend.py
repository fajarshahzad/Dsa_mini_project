import sys
from PyQt5.uic import loadUi
from PyQt5.QtWidgets import *
from PyQt5 import QtCore, QtGui, QtWidgets
import pandas as pd
import time  # For measuring runtime
import Functions as f
import random
import math
class Mainwindow(QMainWindow):
    def __init__(self):
        super(Mainwindow, self).__init__()
        try:
            loadUi('UIPro.ui', self)  # Load the UI file
            print("UI loaded successfully")

            # Check if minimizeButton exists in the UI and connect it to minimize the window
            if hasattr(self, 'minimizeButton'):
                self.minimizeButton.clicked.connect(self.showMinimized)
            
            # Check if CrossButton exists in the UI and connect it to close the window
            if hasattr(self, 'CrossButton'):
                self.CrossButton.clicked.connect(self.close)

            # Set the window background attribute
            self.setAttribute(QtCore.Qt.WA_TranslucentBackground)

            # Load the table data
            self.load_table()

            # Connect sorting button (Assumed to exist in your UI)
            if hasattr(self, 'sortButton'):
                self.sortButton.clicked.connect(self.sort_data)
            if hasattr(self,'loader'):
                self.loader.clicked.connect(self.load_table)
            if hasattr(self,'searchButton'):
                self.searchButton.clicked.connect(self.perform_search)
            #if hasattr(self,'CSVLoader')
                
        except Exception as ex:
            print(f'Error loading UI: {str(ex)}')
    def search_data(self, search_term, columns_to_search):
        #Search for the data in the specified columns and update the data grid with the results.
        self.Data_Grid.setModel(QtGui.QStandardItemModel())  # Clear current grid

        model = QtGui.QStandardItemModel()
        model.setHorizontalHeaderLabels(self.df.columns.tolist())  # Set headers

    # Search for the term in the selected columns
        for row in self.df.values.tolist():
            for col_idx in columns_to_search:
                if search_term.lower() in str(row[col_idx]).lower():
                    items = [QtGui.QStandardItem(str(field)) for field in row]
                    model.appendRow(items)
                    break

    # Update grid with search results
        self.Data_Grid.setModel(model)

        if model.rowCount() == 0:
            QMessageBox.information(self, 'No Results', 'No data found for the search term.')

    def perform_search_whole(self):
        #Perform search when the search button is clicked.
        search_term = self.search.text()  # Get search term
        columns_to_search = [0, 2,3,4,5,6,7]
        self.search_data(search_term,columns_to_search)

    def perform_search(self):
        """Perform search when the search button is clicked."""
        try:
            search_term = self.search.text()  # Get the search term from a QLineEdit widget
            selected_column = self.get_selected_column_index()  # Assuming a combo box to select a single column
            multiple_column = [self.get_selected_column_index(), self.get_selected_column_index()]
            columns_to_search = [0, 1, 2, 3, 4, 5, 6]  # Assume 7 columns (index starts from 0)

        # Determine which search type to use based on user input (radio buttons or dropdown)
            search_type = self.searchcombo.currentText()  # Dropdown for search type (Single, AND, OR, NOT)

            if not search_term:  # If the search term is empty, raise a custom error
                raise ValueError("Search term cannot be empty.")

            if search_type == "Search column wise":
                if selected_column is None:
                    raise ValueError("No column selected for search.")
                self.search_in_single_column(search_term, selected_column)

            elif search_type == "Search Whole":
                self.perform_search_whole()

            elif search_type == "Search multicolumn using And":
                if None in multiple_column:
                    raise ValueError("Both columns must be selected for AND search.")
                self.search_in_multiple_columns_and(search_term, multiple_column)

            elif search_type == "Search multicolumn using OR":
                if None in multiple_column:
                    raise ValueError("Both columns must be selected for OR search.")
                self.search_in_multiple_columns_or(search_term, multiple_column)

            elif search_type == "Search using NOT":
                self.search_in_multiple_columns_not(search_term, columns_to_search)

            else:
                raise ValueError("Invalid search type selected.")

        except ValueError as ve:
        # Handle specific errors such as empty search term or invalid selection
            QMessageBox.warning(self, 'Input Error', str(ve))

        except IndexError as ie:
        # Handle errors like index out of range for column selection
            QMessageBox.warning(self, 'Index Error', 'Invalid column index selected.')

        except Exception as e:
        # Catch any other unexpected exceptions and log them
            QMessageBox.critical(self, 'Error', f"An unexpected error occurred: {str(e)}")
            print(f"Error: {e}")  # Optionally log the error to the console for debugging


    def search_in_single_column(self, search_term, column_index):
        """Search for the term in a single specified column and update the data grid."""
        self.Data_Grid.setModel(QtGui.QStandardItemModel())  # Clear current grid
        model = QtGui.QStandardItemModel()
        model.setHorizontalHeaderLabels(self.df.columns.tolist())  # Set headers

        matched_rows = set()  # To store unique matching rows

    # Search term in the selected column
        for row_index, row in enumerate(self.df.values.tolist()):
            if search_term.lower() in str(row[column_index]).lower():
                matched_rows.add(row_index)  # Add the matching row index to the set

    # Populate the data grid with the matching rows
        for row_index in matched_rows:
            items = [QtGui.QStandardItem(str(field)) for field in self.df.iloc[row_index]]
            model.appendRow(items)

        self.Data_Grid.setModel(model)

        if model.rowCount() == 0:
            QMessageBox.information(self, 'No Results', 'No data found for the search term.')
    def search_in_multiple_columns_and(self, search_term, columns_to_search):
        """Search for the term in multiple columns where all conditions (AND) must be met."""
        self.Data_Grid.setModel(QtGui.QStandardItemModel())  # Clear current grid
        model = QtGui.QStandardItemModel()
        model.setHorizontalHeaderLabels(self.df.columns.tolist())  # Set headers

        matched_rows = set()  # To store unique matching rows
        if len(columns_to_search) < 2:
            QMessageBox.warning(self, 'Selection Error', 'Please select at least two columns for AND search.')
            return
    # Search term in all specified columns (AND logic)
        for row_index, row in enumerate(self.df.values.tolist()):
            if all(search_term.lower() in str(row[col_idx]).lower() for col_idx in columns_to_search):
                matched_rows.add(row_index)

    # Populate the data grid with the matching rows
        for row_index in matched_rows:
            items = [QtGui.QStandardItem(str(field)) for field in self.df.iloc[row_index]]
            model.appendRow(items)

        self.Data_Grid.setModel(model)

        if model.rowCount() == 0:
            QMessageBox.information(self, 'No Results', 'No data found for the search term.')

    def search_in_multiple_columns_or(self, search_term, columns_to_search):
        """Search for the term in multiple columns where any condition (OR) can be met."""
        self.Data_Grid.setModel(QtGui.QStandardItemModel())  # Clear current grid
        model = QtGui.QStandardItemModel()
        model.setHorizontalHeaderLabels(self.df.columns.tolist())  # Set headers

        matched_rows = set()  # To store unique matching rows

    # Search term in any of the specified columns (OR logic)
        for row_index, row in enumerate(self.df.values.tolist()):
            if any(search_term.lower() in str(row[col_idx]).lower() for col_idx in columns_to_search):
                matched_rows.add(row_index)

    # Populate the data grid with the matching rows
        for row_index in matched_rows:
            items = [QtGui.QStandardItem(str(field)) for field in self.df.iloc[row_index]]
            model.appendRow(items)

        self.Data_Grid.setModel(model)

        if model.rowCount() == 0:
            QMessageBox.information(self, 'No Results', 'No data found for the search term.')

    def search_in_multiple_columns_not(self, search_term, columns_to_search):
        """Search for the term in multiple columns where the term must NOT be in any column."""
        self.Data_Grid.setModel(QtGui.QStandardItemModel())  # Clear current grid
        model = QtGui.QStandardItemModel()
        model.setHorizontalHeaderLabels(self.df.columns.tolist())  # Set headers

        matched_rows = set()  # To store unique matching rows

    # Search term in all specified columns (NOT logic)
        for row_index, row in enumerate(self.df.values.tolist()):
            if all(search_term.lower() not in str(row[col_idx]).lower() for col_idx in columns_to_search):
                matched_rows.add(row_index)

    # Populate the data grid with the matching rows
        for row_index in matched_rows:
            items = [QtGui.QStandardItem(str(field)) for field in self.df.iloc[row_index]]
            model.appendRow(items)

        self.Data_Grid.setModel(model)

        if model.rowCount() == 0:
            QMessageBox.information(self, 'No Results', 'No data found for the search term.')

    def reload_data(self):
        """Reload the original data in the data grid."""
        self.load_table()  # Assuming `load_table()` reloads the full data

    def load_table(self):
        """Load data from CSV into the table view."""
        try:
            # Load the CSV file
            self.df = pd.read_csv('Data_1.csv')
            print(f"CSV data loaded successfully: {self.df.shape}")

            if not self.df.empty:
                # Create a model for the table
                model = QtGui.QStandardItemModel()
                model.setHorizontalHeaderLabels(self.df.columns.tolist())  # Set header labels

                # Add rows to the model
                for row in self.df.values.tolist():
                    items = [QtGui.QStandardItem(str(field)) for field in row]
                    model.appendRow(items)

                # Assign the model to the QTableView (Data_Grid)
                self.Data_Grid.setModel(model)
                   # Stretch the columns to fit the data
                for i in range(len(self.df.columns)):
                    
                    self.Data_Grid.resizeColumnToContents(i)
                print("Data successfully loaded into table.")
            else:
                QMessageBox.warning(self, 'Warning', 'CSV File is empty')
                print("CSV file is empty")

        except FileNotFoundError:
            QMessageBox.warning(self, 'Error', 'CSV File not found')
            print("CSV file not found")
        except pd.errors.EmptyDataError:
            QMessageBox.warning(self, 'Error', 'CSV file is empty')
            print("CSV file is empty")
        except Exception as ex:
            QMessageBox.warning(self, 'Error', f'Error loading table: {str(ex)}')
            print(f"Error loading table: {str(ex)}")

    def get_selected_column_index(self):
        """Get the selected column index from the table view."""
        selected_indexes = self.Data_Grid.selectionModel().selectedColumns()
        if selected_indexes:
            return selected_indexes[0].column()
        else:
            return None

    def sort_data(self):
        """Sort data using the selected algorithm and update the table with progress."""
        try:
            selected_column_index = self.get_selected_column_index()
            if selected_column_index is None:
                QMessageBox.warning(self, 'Error', 'No column selected for sorting')
                return

            column_data = self.df.iloc[:, selected_column_index].tolist()  # Sorting the selected column
            selected_algorithm = self.txt_algorithm.currentText()

            # Apply the sorting algorithm
            start_time = time.time()

            # Initialize progress bar to 0
            self.progressBar_2.setValue(0)

            if selected_algorithm   == 'Bubble Sort':
                sorted_data, sorted_indices = self.bubble_sort_with_progress(column_data)
            elif selected_algorithm == 'Selection Sort':
                sorted_data, sorted_indices = self.selection_sort_with_progress(column_data)
            elif selected_algorithm == 'Insertion Sort':
                sorted_data, sorted_indices = self.insertion_sort_with_progress(column_data)
            elif selected_algorithm == 'Quick Sort':
                sorted_data, sorted_indices = self.quick_sort_with_progress(column_data)
            elif selected_algorithm == 'Count Sort':
                sorted_data, sorted_indices = self.counting_sort_with_progress(column_data)
            elif selected_algorithm == 'Radix Sort':
                sorted_data, sorted_indices = self.radix_sort_with_progress(column_data)
            elif selected_algorithm == 'Bucket Sort':
                sorted_data, sorted_indices = self.bucket_sort_with_progress(column_data)
            elif selected_algorithm == 'Merge Sort':
                sorted_data, sorted_indices = self.merge_sort_with_progress(column_data)
            elif selected_algorithm == 'Heap Sort':
                sorted_data,sorted_indices=self.heap_sort_with_progress(column_data)
            elif selected_algorithm == 'Shell Sort':
                sorted_data,sorted_indices= self.shell_sort_with_progress(column_data)
            else:
                QMessageBox.warning(self, 'Error', 'Unknown sorting algorithm selected')
                return

            end_time = time.time()
            run_time = end_time - start_time

            # Update the DataFrame with sorted data
            self.df = self.df.iloc[sorted_indices].reset_index(drop=True)
            self.reload_sorted_table()

            # Display the sorting runtime
            self.runtime.setText(f'The sorting took {run_time:.5f} seconds')

            # Set progress bar to 100% after completion
            self.progressBar_2.setValue(100)

        except Exception as ex:
            QMessageBox.warning(self, 'Error', f'Error sorting data: {str(ex)}')

    def bubble_sort_with_progress(self, data):
        """Bubble sort algorithm with progress bar updates."""
        n = len(data)
        indices = list(range(n))
        for i in range(n):
            for j in range(0, n-i-1):
                if str(data[j]) > str(data[j+1]):
                    data[j], data[j+1] = data[j+1], data[j]
                    indices[j], indices[j+1] = indices[j+1], indices[j]
            
            # Update progress bar: progress depends on outer loop completion
            progress = int((i / n) * 100)
            self.progressBar_2.setValue(progress)

            # Allow Qt to update the GUI (progress bar) while sorting
            QtWidgets.QApplication.processEvents()

        return data, indices

    def selection_sort_with_progress(self, data):
        """Selection sort algorithm that handles multiple data types with progress bar updates."""
        n = len(data)
        indices = list(range(n))

        for i in range(n):
            min_idx = i
            for j in range(i + 1, n):
            # Convert to string for comparison to handle different data types
                if str(data[j]) < str(data[min_idx]):
                    min_idx = j

        # Swap the elements and their indices
            data[i], data[min_idx] = data[min_idx], data[i]
            indices[i], indices[min_idx] = indices[min_idx], indices[i]

        # Update progress bar
            progress = int((i / n) * 100)
            self.progressBar_2.setValue(progress)
            QtWidgets.QApplication.processEvents()

        return data, indices


    def insertion_sort_with_progress(self, data):
        """Insertion sort algorithm with progress bar updates."""
        n = len(data)
        indices = list(range(n))
        for i in range(1, n):
            key = data[i]
            key_index = indices[i]
            j = i - 1
            while j >= 0 and key < data[j]:
                data[j + 1] = data[j]
                indices[j + 1] = indices[j]
                j -= 1
            data[j + 1] = key
            indices[j + 1] = key_index

            # Update progress bar
            progress = int((i / n) * 100)
            self.progressBar_2.setValue(progress)
            QtWidgets.QApplication.processEvents()

        return data, indices
    def quick_sort_with_progress(self, arr):
        if len(arr) <= 1:
            return arr, list(range(len(arr)))  # Return array and original indices if length <= 1

    # Define a custom comparison function
        def type_order(value):
            if isinstance(value, (int, float)):
                return (0, value)  # Numeric types come first
            elif isinstance(value, str):
                return (1, value)  # Strings come second
            return (2, value)  # Other types can be pushed at the end if necessary

    # Track original indices
        indices = list(range(len(arr)))

    # Recursive quicksort with index tracking
        def quick_sort_recursive(arr, idx):
            if len(arr) <= 1:
                return arr, idx  # Base case: return array and indices if length <= 1

            pivot = arr[len(arr) // 2]
            left = [arr[i] for i in range(len(arr)) if type_order(arr[i]) < type_order(pivot)]
            left_idx = [idx[i] for i in range(len(arr)) if type_order(arr[i]) < type_order(pivot)]
        
            middle = [arr[i] for i in range(len(arr)) if type_order(arr[i]) == type_order(pivot)]
            middle_idx = [idx[i] for i in range(len(arr)) if type_order(arr[i]) == type_order(pivot)]
        
            right = [arr[i] for i in range(len(arr)) if type_order(arr[i]) > type_order(pivot)]
            right_idx = [idx[i] for i in range(len(arr)) if type_order(arr[i]) > type_order(pivot)]

            sorted_left, sorted_left_idx = quick_sort_recursive(left, left_idx)
            sorted_right, sorted_right_idx = quick_sort_recursive(right, right_idx)

            return sorted_left + middle + sorted_right, sorted_left_idx + middle_idx + sorted_right_idx

    # Start quicksort
        sorted_arr, sorted_indices = quick_sort_recursive(arr, indices)

    # Update progress bar to 100% after sorting is done
        self.progressBar_2.setValue(100)
        QtWidgets.QApplication.processEvents()

        return sorted_arr, sorted_indices

    def counting_sort_with_progress(self, data):
        """Counting sort algorithm with progress bar updates."""
        if not all(isinstance(x, (int, float)) for x in data):
            QtWidgets.QMessageBox.warning(None, "Warning", "Counting sort can only be applied to numeric data.")
        max_val = max(data)
        min_val = min(data)
        range_of_elements = max_val - min_val + 1
        count_arr = [0] * range_of_elements
        output_arr = [0] * len(data)
        indices = list(range(len(data)))
        output_indices = [0] * len(data)

        for i in range(len(data)):
            count_arr[data[i] - min_val] += 1

        for i in range(1, len(count_arr)):
            count_arr[i] += count_arr[i - 1]

        for i in range(len(data) - 1, -1, -1):
            output_arr[count_arr[data[i] - min_val] - 1] = data[i]
            output_indices[count_arr[data[i] - min_val] - 1] = indices[i]
            count_arr[data[i] - min_val] -= 1

            # Update progress bar
            progress = int(((len(data) - i) / len(data)) * 100)
            self.progressBar_2.setValue(progress)
            QtWidgets.QApplication.processEvents()

        return output_arr, output_indices

    def radix_sort_with_progress(self, data):
        """Radix sort algorithm with progress bar updates."""
        # Check if the data contains any non-numeric elements (e.g., strings)
        if not all(isinstance(x, (int, float)) for x in data):
            QtWidgets.QMessageBox.warning(None, "Warning", "Radix sort can only be applied to numeric data.")
            return data, list(range(len(data)))  # Return the original data unchanged
    
    # Convert floats to integers by scaling (since radix sort works with integers)
        scale_factor = 1
        if any(isinstance(x, float) for x in data):
            scale_factor = 10 ** max(len(str(x).split('.')[1]) for x in data if isinstance(x, float))
            data = [int(x * scale_factor) for x in data]
        indices = list(range(len(data)))

        def counting_sort_for_radix(arr, idx, exp):
            n = len(arr)
            output = [0] * n
            output_idx = [0] * n
            count = [0] * 10

            for i in range(n):
                index = arr[i] // exp
                count[index % 10] += 1

            for i in range(1, 10):
                count[i] += count[i - 1]

            for i in range(n - 1, -1, -1):
                index = arr[i] // exp
                output[count[index % 10] - 1] = arr[i]
                output_idx[count[index % 10] - 1] = idx[i]
                count[index % 10] -= 1

            for i in range(n):
                arr[i] = output[i]
                idx[i] = output_idx[i]
        max_val = max(data)
        exp = 1
        total_digits = len(str(max_val))

    # Perform radix sort (using counting sort as a subroutine) for each digit
        while max_val // exp > 0:
            counting_sort_for_radix(data, indices, exp)
            exp *= 10

        # Update the progress bar based on the current digit being processed
            progress = int((exp / (10 ** total_digits)) * 100)
            self.progressBar_2.setValue(progress)
            QtWidgets.QApplication.processEvents()

    # If floats were scaled, scale them back to original values
        if scale_factor > 1:
            data = [x / scale_factor for x in data]

    # Update the progress bar to 100%
        self.progressBar_2.setValue(100)
        QtWidgets.QApplication.processEvents()

        return data, indices

    def bucket_sort_with_progress(self, data):
        """Bucket sort algorithm that handles multiple data types and NaN values, with progress bar updates."""
        n = len(data)
        if n == 0:
            return [], []  # If the data is empty, return empty results

    # Helper function to determine type order
        def type_order(val):
            if isinstance(val, (int, float)):
                return (0, val)  # Numbers come first
            elif isinstance(val, str):
                return (1, val)  # Strings come after numbers
            return (2, val)  # Other types go last

    # Separate numeric data, NaN values, and strings for bucket placement
            numeric_data = [x for x in data if isinstance(x, (int, float)) and not math.isnan(x)]
            nan_data = [x for x in data if isinstance(x, (int, float)) and math.isnan(x)]
            string_data = [x for x in data if isinstance(x, str)]

    # Handle numbers first if we have any numeric data
            result = []
            result_indices = []
            indices = list(range(n))

            if numeric_data:
                max_val = max(numeric_data)
                min_val = min(numeric_data)
                size = (max_val - min_val) / n if max_val != min_val else 1  # Avoid division by zero

        # Create buckets and bucket_indices for numeric data
                buckets = [[] for _ in range(n)]
                bucket_indices = [[] for _ in range(n)]

                for i in range(n):
                    if isinstance(data[i], (int, float)) and not math.isnan(data[i]):
                # Place numeric data into the appropriate bucket
                        bucket_idx = min(int((data[i] - min_val) / size), n - 1)  # Cap bucket index
                        buckets[bucket_idx].append(data[i])
                        bucket_indices[bucket_idx].append(indices[i])

        # Sort each numeric bucket
                for i in range(n):
                    sorted_bucket = sorted(zip(buckets[i], bucket_indices[i]), key=lambda x: x[0])  # Sort by actual value
                    result.extend([x[0] for x in sorted_bucket])
                    result_indices.extend([x[1] for x in sorted_bucket])


    # Handle NaN values by appending them at the end (no sorting for NaN)
            result.extend(nan_data)
            result_indices.extend([indices[i] for i in range(n) if math.isnan(data[i])])

    # Handle strings separately
            if string_data:
                string_buckets = [[] for _ in range(n)]
                string_bucket_indices = [[] for _ in range(n)]
        
                for i in range(n):
                    if isinstance(data[i], str):
                # Place string data into appropriate "bucket"
                        bucket_idx = ord(data[i][0]) % n  # Basic bucket assignment using the first character
                        string_buckets[bucket_idx].append(data[i])
                        string_bucket_indices[bucket_idx].append(indices[i])

        # Sort each string bucket lexicographically
                for i in range(n):
                    sorted_string_bucket = sorted(zip(string_buckets[i], string_bucket_indices[i]), key=lambda x: x[0])
                    result.extend([x[0] for x in sorted_string_bucket])
                    result_indices.extend([x[1] for x in sorted_string_bucket])

    # Final progress update
            self.progressBar_2.setValue(100)
            QtWidgets.QApplication.processEvents()

            return result, result_indices

    def merge_sort_with_progress(self, data):
        """Merge sort algorithm with progress bar updates."""
        indices = list(range(len(data)))

        def merge_sort_recursive(arr, idx):
            if len(arr) > 1:
                mid = len(arr) // 2
                L = arr[:mid]
                R = arr[mid:]
                L_idx = idx[:mid]
                R_idx = idx[mid:]

                merge_sort_recursive(L, L_idx)
                merge_sort_recursive(R, R_idx)

                i = j = k = 0

                while i < len(L) and j < len(R):
                    if L[i] < R[j]:
                        arr[k] = L[i]
                        idx[k] = L_idx[i]
                        i += 1
                    else:
                        arr[k] = R[j]
                        idx[k] = R_idx[j]
                        j += 1
                    k += 1

                while i < len(L):
                    arr[k] = L[i]
                    idx[k] = L_idx[i]
                    i += 1
                    k += 1

                while j < len(R):
                    arr[k] = R[j]
                    idx[k] = R_idx[j]
                    j += 1
                    k += 1

        merge_sort_recursive(data, indices)

        # Update progress bar
        self.progressBar_2.setValue(100)
        QtWidgets.QApplication.processEvents()

        return data, indices

    def heap_sort_with_progress(self,arr):
        n = len(arr)
        idx = list(range(n))  # Initialize original indices

    # Build a max heap
        for i in range(n // 2 - 1, -1, -1):
            heapify_array(arr,idx,n,i)

    # One by one extract elements from the heap
        for i in range(n - 1, 0, -1):
            arr[i], arr[0] = arr[0], arr[i]  # Swap the root (max element) with the last element
            idx[i], idx[0] = idx[0], idx[i]  # Swap indices accordingly
            #heapify(arr, idx, i, 0)  # Heapify the reduced heap
            heapify_array(arr,idx,i,0)
        self.progressBar_2.setValue(100)
        QtWidgets.QApplication.processEvents()   
        return arr, idx 
    def heapify_array(arr, idx, n, i):
    # Custom comparison function to handle mixed types (int, float, str)
        def type_order(value):
            if isinstance(value, (int, float)):
                return (0, value)  # Numeric types come first
            elif isinstance(value, str):
                return (1, value)  # Strings come second
            return (2, value)  # Other types can be pushed at the end if necessary

        largest = i  # Initialize largest as root
        left = 2 * i + 1  # Left child
        right = 2 * i + 2  # Right child

    # Compare left child with root
        if left < n and type_order(arr[left]) > type_order(arr[largest]):
            largest = left

    # Compare right child with the largest so far
        if right < n and type_order(arr[right]) > type_order(arr[largest]):
            largest = right

    # If the largest is not root
        if largest != i:
            arr[i], arr[largest] = arr[largest], arr[i]  # Swap values
            idx[i], idx[largest] = idx[largest], idx[i]  # Swap corresponding indices

        # Recursively heapify the affected sub-tree
            heapify_array(arr, idx, n, largest)
    def shell_sort_with_progress(self, data):
        """Shell sort algorithm with progress bar updates."""
        n = len(data)
        indices = list(range(n))
        gap = n // 2

        def type_order(value):
            """Custom ordering function to handle both numbers and strings."""
            if isinstance(value, (int, float)):
                return (0, value)  # Numeric types come first
            elif isinstance(value, str):
                return (1, value)  # Strings come second
            return (2, value)  # Other types (if any) can be pushed to the end

        while gap > 0:
            for i in range(gap, n):
                temp = data[i]
                temp_idx = indices[i]
                j = i
            # Corrected comparison: using custom type_order function
                while j >= gap and type_order(data[j - gap]) > type_order(temp):
                    data[j] = data[j - gap]
                    indices[j] = indices[j - gap]
                    j -= gap
                data[j] = temp
                indices[j] = temp_idx

        # Update progress bar based on gap reduction
            progress = int(((n // gap) / n) * 100)
            self.progressBar_2.setValue(progress)

        # Allow Qt to update the GUI (progress bar) while sorting
            QtWidgets.QApplication.processEvents()

            gap //= 2  # Reduce the gap size

    # Final update to 100% progress
        self.progressBar_2.setValue(100)
        QtWidgets.QApplication.processEvents()

        return data, indices

    def reload_sorted_table(self):
        """Reload the sorted data into the table."""
        try:
            # Clear the previous data
            model = self.Data_Grid.model()
            model.clear()

            # Reload the sorted data into the table
            model.setHorizontalHeaderLabels(self.df.columns.tolist())

            for row in self.df.values.tolist():
                items = [QtGui.QStandardItem(str(field)) for field in row]
                model.appendRow(items)

            self.Data_Grid.setModel(model)

        except Exception as ex:
            QMessageBox.warning(self, 'Error', f'Error reloading sorted table: {str(ex)}')
if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = Mainwindow()
    window.show()
    sys.exit(app.exec())
