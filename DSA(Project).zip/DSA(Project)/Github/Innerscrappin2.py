from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd
import time

# webdriver can be downloaded from
# https://sites.google.com/chromium.org/driver/downloads/versionselection?authuser=0
def Scrap():
    service = Service(executable_path="F:\\3rd Sem\\DSA Lab\\Week 3\\chromedriver-win64\\chromedriver.exe")
    options = webdriver.ChromeOptions()
    driver = webdriver.Chrome(service=service, options=options)
    options.add_argument('--blink-settings=imagesEnabled=false')
    options.add_experimental_option("prefs", {"profile.managed_default_content_settings.images": 2})
    Issues = []
    PullRequests = []
    Forks = []
    Data = pd.read_csv('Github2.csv')
    Names = Data["Name"].values.tolist()
    for i in Names:
        driver.get(f'https://github.com/{i}')
        wait = WebDriverWait(driver,10)
        try:
            issuesCount = wait.until(EC.visibility_of_element_located((By.ID("issues-repo-tab-count"))))
            Issues.append(issuesCount.text.strip())
        except Exception as ex:
            print(f'contributors not found fo r{i} due to {ex}')
            Issues.append(0) 
        try:
            requestCount = wait.until(EC.visibility_of_element_located((By.ID("pull-requests-repo-tab-count"))))
            PullRequests.append(requestCount.text.strip())
        except Exception as ex:
            print(f'Watch not found fo r{i} due to {ex}')
            PullRequests.append(0) 
        try:
            forkCount = wait.until(EC.visibility_of_element_located((By.XPATH("repo-network-counter"))))
            Forks.append(forkCount.text.strip())
        except Exception as ex:
            print(f'Forks not found fo r{i} due to {ex}')
            Forks.append(None)            
    Data["Issues"] = Issues
    Data["Forks"] = Forks
    Data["Pull Requests"] = PullRequests
    Data.to_csv("Github2.csv",index=False)         