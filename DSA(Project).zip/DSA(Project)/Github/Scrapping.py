from selenium import webdriver
from bs4 import BeautifulSoup
import pandas as pd
from selenium.webdriver.chrome.service import Service
import time as sleep

# webdriver can be downloaded from
# https://sites.google.com/chromium.org/driver/downloads/versionselection?authuser=0

service = Service(executable_path="F:\\3rd Sem\\DSA Lab\\Week 3\\chromedriver-win64\\chromedriver.exe")
options = webdriver.ChromeOptions()
driver = webdriver.Chrome(service=service, options=options)
# driver = webdriver.Chrome(executable_path='C:/Program Files/chromedriver-win64/chromedriver.exe')
Name = []
Description = []
Language = []
Stars = []
LastUpdated = []
contributors = []
Watch = []
Forks = []

for i in range(2,10):
    driver.get(f'https://github.com/search?q=web+dev&type=repositories&p={i}')

    content = driver.page_source

    soup = BeautifulSoup(content, features="html.parser")
    # print(soup)
    for a in soup.findAll("div", attrs={"class": "flszRz"}):
        print(a)
        RepoName = a.find("a",attrs = {"class":"dIlPa"})
        RepoDescription = a.find("span",attrs = {"class":"cWNlgR"})
        language = a.find("li",attrs = {"class":"iyzdzM"})
        StarsGained = a.find("span",attrs = {"class":"hWqAbU"})
        Update = a.find("div",attrs = {"class":"liVpTx"})
        driver.get(f'https://github.com/{i}')

        content = driver.page_source

        soup2 = BeautifulSoup(content, features="html.parser")
            # print(soup)
        for a in soup2.findAll("div", attrs={"id": "repository-details-container"}):
                print(a)
                # contributors = a.find("a",attrs = {"class":"dIlPa"})
                Watchers = a.find("span",attrs = {"class":"Counter"})
                Fork = a.find("span",attrs = {"id":"repo-network-counter"})
                # topics = a.find("a",attrs = {"class":"hgRXpf"})
                if Watchers != None and Fork:
                    Watch.append(Watchers.text)
                    Forks.append(Fork.text)
                    # Topics.append(topics.text)
                if len(Name) == 150:
                    break
        # Profile = a.find("div",attrs = {"class":"eurdCD"})
        # topics = a.find("a",attrs = {"class":"hgRXpf"})
        if RepoName != None and RepoDescription != None and language != None and StarsGained != None and Update != None:
            Name.append(RepoName.text)
            Description.append(RepoDescription.text)
            Language.append(language.text)
            Stars.append(StarsGained.text)
            LastUpdated.append(Update.text)
            # Watch.append(Watchers.text)
            # Forks.append(Fork.text)
            # profilePhoto.append(Profile.src)
            # Topics.append(topics.text)
        if len(Name) == 10:
            break
    
    df = pd.DataFrame({"Name": Name, "Description":Description,"Language":Language,"Stars Gained":Stars,"Last Updated":LastUpdated,"Watch":Watch,"Forks":Forks})
    df.to_csv("Github.csv", encoding="utf-8")
    
# service = Service(executable_path="F:\\3rd Sem\\DSA Lab\\Week 3\\chromedriver-win64\\chromedriver.exe")
# options = webdriver.ChromeOptions()
# driver = webdriver.Chrome(service=service, options=options)
# for i in Name:
#         driver.get(f'https://github.com/{RepoName}')

#         content = driver.page_source

#         soup2 = BeautifulSoup(content, features="html.parser")
#         print(soup)
#         for a in soup2.findAll("div", attrs={"id": "Layout-sidebar"}):
#                 print(a)
                
#                 Watchers = a.find("strong")
#                 Fork = a.find("strong")
#                 Contributor = a.find("span",attrs = {"class":"counter"})
#                 # topics = a.find("a",attrs = {"class":"hgRXpf"})
#                 if Watchers != None and Fork != None and Contributor != None:
#                     Watch.append(Watchers.text)
#                     Forks.append(Fork.text)
#                     contributors.append(Contributor.text)
#                     # Topics.append(topics.text)
#                 if len(Name) == 10:
#                     break
# df2 = pd.DataFrame({"Watch":Watch,"Forks":Forks,"Contributors":contributors})
# df2.to_csv("Watch.csv",encoding="utf-8")