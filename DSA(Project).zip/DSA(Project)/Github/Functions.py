import random
### Insertion Sort
def InsertionSort(array):
    for i in range(1,len(array)):
        key=array[i]
        j=i-1
        while j>=0 and array[j]>key:
            array[j+1]=array[j]
            j-=1
        array[j+1]=key
### Merge arrays
""""
def Merge(array,p,q,r):
    left_half = array[p:q+1]
    right_half = array[q+1:r+1]

    i = j = 0 
    k = p  
    while i < len(left_half) and j < len(right_half):
        if left_half[i] <= right_half[j]:
            array[k] = left_half[i]
            i += 1
        else:
            array[k] = right_half[j]
            j += 1
        k += 1
    while i < len(left_half):
        array[k] = left_half[i]
        i += 1
        k += 1
    while j < len(right_half):
        array[k] = right_half[j]
        j += 1
        k += 1
"""
### Merge Sort
def Merge_sort(arr):
    if len(arr) > 1:
        mid = len(arr) // 2  # Finding the mid of the array
        L = arr[:mid]  # Dividing the elements into 2 halves
        R = arr[mid:]

        Merge_sort(L)  # Sorting the first half
        Merge_sort(R)  # Sorting the second half

        i = j = k = 0

        # Copy data to temp arrays L[] and R[]
        while i < len(L) and j < len(R):
            if L[i] < R[j]:
                arr[k] = L[i]
                i += 1
            else:
                arr[k] = R[j]
                j += 1
            k += 1

        # Checking if any element was left
        while i < len(L):
            arr[k] = L[i]
            i += 1
            k += 1

        while j < len(R):
            arr[k] = R[j]
            j += 1
            k += 1

    return arr
### Bubble Sort
def BubbleSort(array):
    for i in range(len(array)):
        for j in range(0,len(array)-i-1):
            if(array[j]> array[j+1]):
                array[j],array[j+1]=array[j+1],array[j]
    return array
### Selection Sort
def SelectionSort(array):
    for i in range(len(array)):
        min_index =i
        for j in range (i+1,len(array)):
            if array[j]<array[min_index]:
                min_index=j
        array[min_index],array[i]=array[i],array[min_index]
    return array
### Hybrid Merge Sort
def HybridMergeSort(Array):
    start_index=0
    end_index=len(array)-1
    if end_index - start_index <= 5:
        InsertionSort(Array, start_index, end_index)
    else:
        if start_index < end_index:
            mid = (start_index + end_index) // 2  
            HybridMergeSort(Array, start_index, mid)
            HybridMergeSort(Array, mid + 1, end_index)
            Merge(Array, start_index, mid, end_index)
#### Bucket Sort
def Bucket_sort_strings(array):
    """Sort an array of strings using Bucket Sort."""
    # Create an empty list of buckets
    buckets = [[] for _ in range(256)]  # Assuming ASCII characters

    # Distribute strings into buckets based on their first character
    for string in array:
        # Use the ASCII value of the first character as the bucket index
        index = ord(string[0]) if string else 0  # Handle empty strings
        buckets[index].append(string)

    # Sort each bucket and concatenate the results
    sorted_array = []
    for bucket in buckets:
        # Sort each bucket using Python's built-in sort or any other sorting method
        sorted_bucket = sorted(bucket)  # You can replace this with any other sorting algorithm
        sorted_array.extend(sorted_bucket)

    return sorted_array
""""
def BucketSort(array):
    length=len(array)
    output_array=[]
    number_of_buckets=[[]for _ in range(length)]
    for num in array:
        index=int(length*num)
        number_of_buckets[index].append(num)
    for bucket in number_of_buckets:
        bucket.sort()
    for bucket in number_of_buckets:
        output_array.extend(bucket)
    return output_array
### Counting Sort
def CountingSort(array):
    min_val=min(array) 
    k=max(array)-min_val
    intermediate_array=[0]*(k + 1)
    output=[]
    for j in array:
        intermediate_array[j-min_val]+=1
    for i in range(len(intermediate_array)):
        for _ in range(intermediate_array[i]):
            output.append(i+min_val) 
    return output
"""
## Count Sort
def Counting_Sort_Strings(array):
    """Sort an array of strings lexicographically using Counting Sort."""
    max_len = max(len(s) for s in array)  # Find the maximum string length
    output = [''] * len(array)  # Output array to hold sorted strings
    count = [0] * 256  # Count array for ASCII characters (0-255)

    # Iterate from the last character position to the first
    for pos in range(max_len - 1, -1, -1):
        # Reset count array
        count = [0] * 256

        # Count occurrences of characters at the current position
        for string in array:
            char = string[pos] if pos < len(string) else '\0'  # Use '\0' for shorter strings
            count[ord(char)] += 1  # Increment the count for this character

        # Change count[i] to the actual position in the output array
        for i in range(1, 256):
            count[i] += count[i - 1]

        # Build the output array
        for i in range(len(array) - 1, -1, -1):
            char = array[i][pos] if pos < len(array[i]) else '\0'  # Get character at the position
            output[count[ord(char)] - 1] = array[i]  # Place the string in the correct position
            count[ord(char)] -= 1  # Decrease the count for this character

        # Copy the output array to the original array
        for i in range(len(array)):
            array[i] = output[i]

    return array
""""
### Radix Sort
def counting_sort_by_digit(arr, exp):
    n = len(arr)
    output=[0]*n
    count=[0]*10
    for i in range(n):
        index=(arr[i]//exp)%10
        count[index]+=1
    for i in range(1, 10):
        count[i]+=count[i-1]
    for i in range(n-1,-1,-1):
        index=(arr[i]//exp)%10
        output[count[index]-1]=arr[i]
        count[index]-=1
    for i in range(n):
        arr[i]=output[i]
"""
### string vala ha yah
def Radix_sort_strings(arr):
    # Find the maximum length of the strings in the array
    max_len = len(max(arr, key=len))

    # Perform counting sort for each character position
    for pos in range(max_len - 1, -1, -1):  # Start from the last character to the first
        counting_sort_strings(arr, pos)

    return arr
### Quick Sort
def partition(arr, p, r):
    x = arr[p]  # The first element is chosen as the pivot
    a = r          # a starts from the last element
    for b in range(p + 1, r + 1): 
        while b <= a and arr[a] >= x:
            a -= 1
        if b>= a:## Here the a and b cross each other
            break
        if arr[b] > x:
            arr[b], arr[a] = arr[a], arr[b]
    # Swap the pivot with the element
    arr[p], arr[a] = arr[a], arr[p]
    return a 
def Quick_Sort(array):
    if len(array) <= 1:
        return array
    pivot = array[len(array) // 2]
    left = [x for x in array if x < pivot]
    middle = [x for x in array if x == pivot]
    right = [x for x in array if x > pivot]
    return Quick_sort(left) + middle + Quick_sort(right)
    ##p=0
    #r=len(array)-1
    #if p<r:
        #q = partition(array, p, r)
        #Quick_Sort(array, p, q - 1)
        #Quick_Sort(array, q + 1,r)
### Bogo Sort
def is_sorted(arr):
    for i in range(len(arr) - 1):
        if arr[i] > arr[i + 1]:
            return False
    return True
def bogo_sort(arr):
    while not is_sorted(arr):
        random.shuffle(arr) 
    return arr
### Heap Sort
def heapify(arr, n, i):
    largest = i 
    left = 2 * i + 1  
    right = 2 * i + 2 
    if left < n and arr[left] > arr[largest]:
        largest = left
    if right < n and arr[right] > arr[largest]:
        largest = right
    if largest != i:
        arr[i], arr[largest] = arr[largest], arr[i]
        heapify(arr, n, largest)
def heap_sort(arr):
    n = len(arr)
    for i in range(n // 2 - 1, -1, -1): 
        heapify(arr, n, i)
    for i in range(n - 1, 0, -1):
        arr[i], arr[0] = arr[0], arr[i]  
        heapify(arr, i, 0)  